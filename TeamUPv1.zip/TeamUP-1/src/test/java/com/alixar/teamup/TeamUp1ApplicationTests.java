package com.alixar.teamup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeamUp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
