package com.alixar.teamup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamUp1Application {

	public static void main(String[] args) {
		SpringApplication.run(TeamUp1Application.class, args);
	}

}
